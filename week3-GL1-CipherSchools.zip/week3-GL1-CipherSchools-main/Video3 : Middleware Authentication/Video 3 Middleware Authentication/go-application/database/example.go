package database

func Example() {
	Setup()
	exam()
}
